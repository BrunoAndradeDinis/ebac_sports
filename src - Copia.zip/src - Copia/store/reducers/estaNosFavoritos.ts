import { createSlice, PayloadAction } from '@reduxjs/toolkit'
import { EstaNosFavoritos, Produto } from '../../types'
import { useSelector } from 'react-redux'

const initialState: EstaNosFavoritos = {
  estaNosFavoritos: false,
  produto: []
}

const estaNosFavoritos = createSlice({
  name: 'estaNosFavoritos',
  initialState,
  reducers: {
    validaFav: (state, action: PayloadAction<Produto>) => {
      const favs = useSelector((state: RootReducer) => state.favoritos.favs)
      const produtoId = state.id
      const IdsDosFavoritos = favs.map((f) => f.id)

      return IdsDosFavoritos.includes(produtoId)
    }
  }
})
